<h1>Assets do curso de Jogo de Plataforma 2D na Unity</h1>
Nesse repositório você encontra todos os arquivos que utilizamos no curso :)
